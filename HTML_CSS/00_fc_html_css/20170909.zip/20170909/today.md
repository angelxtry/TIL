# 패스트캠퍼스 HTML & CSS 8번째 수업 - 레이아웃

## Layout 201
### Visual formatting model

#### Block formatting context

#### Inline formatting context

### Normal flow

### Line box

### `overflow`

### `box-sizing`

### Static Layout

### Flexible Layout